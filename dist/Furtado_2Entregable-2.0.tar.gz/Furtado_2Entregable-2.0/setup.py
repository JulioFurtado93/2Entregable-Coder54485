from setuptools import setup

setup(
    name="Furtado_2Entregable",
    version="2.0",
    description="Desarrollado para la 2da entrega de la comision 54485 de Python en CoderHouse",
    author="Julio C. Furtado",
    author_email="juliocfurtado93@gmail.com",
    packages= ["Clientes","Productos"]
)